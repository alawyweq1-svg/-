# محاكي قلوب من حديد — مشروع تطبيق أندرويد (APK)

اللعبة ملف واحد يشتغل بدون إنترنت (`www/index.html`) ومغلّف بـ Capacitor.

## الطريقة 1 (الأسهل): البناء السحابي عبر GitHub — بدون تثبيت شي على جهازك
1. سوِّ حساب مجاني على github.com وأنشئ مستودع (Repository) جديد.
2. ارفع **كل محتويات هذا المجلد** (مع مجلد `.github` المخفي) إلى المستودع.
3. ادخل تبويب **Actions** ← **Build APK** ← **Run workflow** (أو يشتغل تلقائياً مع أول رفع).
4. بعد 5–10 دقائق افتح التشغيلة المكتملة ونزّل الملف من **Artifacts → hoi4-apk** (يجي مضغوط، فك الضغط تحصل `app-debug.apk`).
5. انقله للهاتف وثبّته (فعّل «التثبيت من مصادر غير معروفة» إذا طلب).

## الطريقة 2: على جهازك
المتطلبات: Node 20+ وJDK 21 وAndroid Studio (أو Android SDK).
```
npm install
npx cap add android
npx cap sync android
```
ثم أضف في `android/app/src/main/AndroidManifest.xml`:
- داخل وسم `<activity` الصفة: `android:screenOrientation="sensorLandscape"`
- قبل `<application`: `<uses-permission android:name="android.permission.VIBRATE" />`

وابنِ: `cd android && ./gradlew assembleDebug` — الناتج في `android/app/build/outputs/apk/debug/app-debug.apk`
(أو `npx cap open android` وابنِ من Android Studio).

## ملاحظات
- الـ APK هذا **debug** يصلح للتجربة والمشاركة المباشرة. للنشر في Google Play تحتاج توقيعاً (release) وملف AAB.
- التصميم يحتاج WebView حديث (Chrome 111 فما فوق). أغلب الهواتف المحدّثة تدعمه؛ الهواتف القديمة جداً قد تظهر بتنسيق ناقص.
- الحفظ داخل التطبيق يستخدم التخزين المحلي. للنسخ الاحتياطي استخدم «تصدير ملف» من الحفظ والتحميل (يفتح قائمة المشاركة).
- زر الرجوع في أندرويد يغلق النوافذ ثم يعود للقائمة.
- لتغيير الأيقونة: ضع `assets/icon.png` (1024×1024) ثم `npx @capacitor/assets generate --android`.
- لم أستطع تجربة بناء الـ APK نفسه ولا الإضافات الأصلية على جهاز حقيقي من بيئتي؛ جرّب وأخبرني بأي مشكلة.
